DROP DATABASE IF EXISTS gbd;

CREATE DATABASE gbd;

USE gbd;

CREATE TABLE funcionario (
	id  INTEGER UNSIGNED 
		NOT NULL 
        PRIMARY KEY AUTO_INCREMENT,
	nome VARCHAR(50) NOT NULL,
    departamento CHAR(2),
    funcao VARCHAR(20),
    salario DECIMAL(6,2)
);

SHOW databases;
SHOW tables;

DESCRIBE funcionario;
DESCRIBE funcionario id;
DESCRIBE funcionario nome;

INSERT INTO funcionario 
(id, nome, departamento, funcao, salario) 
VALUES 
(1, 'Fulano', '03', 'Programador', 8120);

INSERT INTO funcionario 
(id, nome, departamento, funcao, salario) 
VALUES 
(NULL, 'Ciclano', '02', 'Programador', 3800);

INSERT INTO funcionario 
(salario, departamento, funcao, nome) 
VALUES 
(3800, '01', 'Analista', 'Beltrano');

INSERT INTO funcionario VALUES 
(NULL, 'Tijolinho', '05', 'DBA', 9999.99);

SELECT * FROM funcionario;