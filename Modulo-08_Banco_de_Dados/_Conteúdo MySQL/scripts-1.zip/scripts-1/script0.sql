SELECT VERSION();

SELECT CURRENT_DATE;

SELECT CURRENT_TIME;

SELECT curdate();
SELECT curtime();
# comentário de uma linha

/*
comentário
de 
várias linhas
 */

SELECT current_timestamp();

SELECT USER() AS usuario,
	curdate() AS data_atual, 
    curtime() AS hora;
    
SELECT now() AS agora;

SELECT 5 + 7.5,
	   5 - 7.5,
       5 * 7.5,
       5 / 7.5;
       
SELECT 1 + 2 * 3;
SELECT (1 + 2) * 3;

SELECT power(2, 8); # exponenciação
SELECT sqrt(144); # square root
SELECT 9 DIV 2; # quociente - int
SELECT 9 % 2; # resto da divisão